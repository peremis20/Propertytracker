import React, { useState } from 'react';
import { AuthProvider } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { AnalyticsView } from './components/AnalyticsView';
import { DocumentsView } from './components/DocumentsView';
import { SettingsView } from './components/SettingsView';

export default function App() {
  const [view, setView] = useState<'portfolio' | 'analytics' | 'documents' | 'settings'>('portfolio');

  return (
    <AuthProvider currentView={view} onViewChange={(v) => setView(v as any)}>
      {view === 'portfolio' && <Dashboard />}
      {view === 'analytics' && <AnalyticsView />}
      {view === 'documents' && <DocumentsView />}
      {view === 'settings' && <SettingsView />}
    </AuthProvider>
  );
}
