import React, { useState, useEffect } from 'react';
import { getProperties, getIncome, getExpenses } from '../services/firestore';
import { Property, Income, Expense } from '../types';
import { calculateMonthlyAmount, formatCurrency } from '../lib/utils';
import { PieChart, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';

export function AnalyticsView() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [income, setIncome] = useState<Income[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);

  useEffect(() => {
    const unsubProps = getProperties(setProperties);
    const unsubIncome = getIncome(null, setIncome);
    const unsubExpenses = getExpenses(null, setExpenses);
    return () => {
      unsubProps();
      unsubIncome();
      unsubExpenses();
    };
  }, []);

  const monthlyIncome = income.reduce((sum, inc) => sum + calculateMonthlyAmount(inc.amount, inc.frequency), 0);
  const monthlyExpenses = expenses.reduce((sum, exp) => sum + calculateMonthlyAmount(exp.amount, exp.frequency), 0);
  const monthlyProfit = monthlyIncome - monthlyExpenses;

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-serif">Portfolio Analytics</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">Monthly Revenue</span>
            <TrendingUp size={16} className="text-green-500/50" />
          </div>
          <p className="text-4xl font-serif text-green-600">{formatCurrency(monthlyIncome)}</p>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">Monthly Expenses</span>
            <TrendingDown size={16} className="text-red-500/50" />
          </div>
          <p className="text-4xl font-serif text-red-600">{formatCurrency(monthlyExpenses)}</p>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">Net Cash Flow</span>
            <DollarSign size={16} className="text-[#5A5A40]/50" />
          </div>
          <p className="text-4xl font-serif text-[#1A1A1A]">{formatCurrency(monthlyProfit)}</p>
        </div>
      </div>

      <div className="bg-white p-12 rounded-[32px] border border-black/5 shadow-sm text-center">
        <PieChart size={48} className="mx-auto mb-6 text-[#1A1A1A]/20" />
        <h3 className="text-xl font-serif mb-2">Advanced Analytics Coming Soon</h3>
        <p className="text-[#1A1A1A]/60 italic">We're building powerful visualization tools to help you optimize your portfolio.</p>
      </div>
    </div>
  );
}
