import React, { useState, useEffect } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User
} from 'firebase/auth';
import { auth, db } from '../firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { LogIn, LogOut, User as UserIcon, Settings as SettingsIcon } from 'lucide-react';
import { cn } from '../lib/utils';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  logout: () => Promise<void>;
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ 
  children, 
  onViewChange, 
  currentView 
}: { 
  children: React.ReactNode, 
  onViewChange?: (view: string) => void,
  currentView?: string
}) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userRef = doc(db, 'users', user.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
          const superAdmins = ['peremishealth@gmail.com', 'jimmy@peremis.com'];
          const email = user.email?.toLowerCase() || '';
          
          // Check for pending invite
          const inviteRef = doc(db, 'invites', email);
          const inviteSnap = await getDoc(inviteRef);
          let assignedRole: UserRole = 'viewer';

          if (superAdmins.includes(email)) {
            assignedRole = 'admin';
          } else if (inviteSnap.exists()) {
            assignedRole = inviteSnap.data().role as UserRole;
            // Delete the invite after use
            const { deleteDoc } = await import('firebase/firestore');
            await deleteDoc(inviteRef);
          }

          const newProfile: UserProfile = {
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || '',
            photoURL: user.photoURL || '',
            role: assignedRole,
            createdAt: new Date().toISOString()
          };
          await setDoc(userRef, newProfile);
          setProfile(newProfile);
        } else {
          const currentProfile = userSnap.data() as UserProfile;
          const superAdmins = ['peremishealth@gmail.com', 'jimmy@peremis.com'];
          
          // Auto-promote super admins if they are not already admins
          if (superAdmins.includes(user.email || '') && currentProfile.role !== 'admin') {
            const updatedProfile = { ...currentProfile, role: 'admin' as UserRole };
            await setDoc(userRef, { role: 'admin' }, { merge: true });
            setProfile(updatedProfile);
          } else {
            setProfile(currentProfile);
          }
        }
        setUser(user);
      } else {
        setUser(null);
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const login = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login failed', error);
    }
  };

  const logout = () => signOut(auth);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F5F2ED]">
        <div className="animate-pulse text-[#5A5A40] font-serif italic text-xl">Loading PropTrack...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F2ED] flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-[32px] p-12 shadow-sm border border-black/5 text-center">
          <h1 className="text-4xl font-serif mb-4 text-[#1A1A1A]">PropTrack Pro</h1>
          <p className="text-[#1A1A1A]/60 mb-12 italic">Premium property management for the modern investor.</p>
          <button 
            onClick={login}
            className="w-full bg-[#5A5A40] text-white rounded-full py-4 px-8 flex items-center justify-center gap-3 hover:bg-[#4A4A30] transition-colors font-medium tracking-wide"
          >
            <LogIn size={20} />
            Connect with Google
          </button>
          <p className="mt-8 text-xs text-[#1A1A1A]/40 uppercase tracking-widest">Secure Authentication</p>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, profile, loading, logout }}>
      <div className="min-h-screen bg-[#F5F2ED]">
        <nav className="bg-white border-b border-black/5 px-8 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-8">
          <h2 className="text-xl font-serif tracking-tight cursor-pointer" onClick={() => onViewChange?.('portfolio')}>PropTrack Pro</h2>
          <div className="hidden md:flex items-center gap-6 text-xs uppercase tracking-widest font-medium">
            <span 
              className={cn(
                "cursor-pointer transition-colors", 
                currentView === 'portfolio' ? "text-[#1A1A1A] font-bold" : "text-[#1A1A1A]/60 hover:text-[#1A1A1A]"
              )}
              onClick={() => onViewChange?.('portfolio')}
            >
              Portfolio
            </span>
            <span 
              className={cn(
                "cursor-pointer transition-colors", 
                currentView === 'analytics' ? "text-[#1A1A1A] font-bold" : "text-[#1A1A1A]/60 hover:text-[#1A1A1A]"
              )}
              onClick={() => onViewChange?.('analytics')}
            >
              Analytics
            </span>
            <span 
              className={cn(
                "cursor-pointer transition-colors", 
                currentView === 'documents' ? "text-[#1A1A1A] font-bold" : "text-[#1A1A1A]/60 hover:text-[#1A1A1A]"
              )}
              onClick={() => onViewChange?.('documents')}
            >
              Documents
            </span>
            <span 
              className={cn(
                "cursor-pointer transition-colors", 
                currentView === 'settings' ? "text-[#1A1A1A] font-bold" : "text-[#1A1A1A]/60 hover:text-[#1A1A1A]"
              )}
              onClick={() => onViewChange?.('settings')}
            >
              Settings
            </span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 pr-4 border-r border-black/5">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium">{user.displayName}</p>
              <p className="text-[10px] text-[#1A1A1A]/40 uppercase tracking-tighter">
                {profile?.role || 'Member'}
              </p>
            </div>
            {user.photoURL ? (
              <img src={user.photoURL} alt="Profile" className="w-10 h-10 rounded-full border border-black/5" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-[#5A5A40]/10 flex items-center justify-center text-[#5A5A40]">
                <UserIcon size={20} />
              </div>
            )}
          </div>
          <button 
            onClick={() => onViewChange?.('settings')}
            className="text-[#1A1A1A]/40 hover:text-[#5A5A40] transition-colors"
            title="Settings"
          >
            <SettingsIcon size={20} />
          </button>
          <button 
            onClick={logout}
            className="text-[#1A1A1A]/40 hover:text-red-500 transition-colors"
            title="Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto p-8">
        {children}
      </main>
    </div>
    </AuthContext.Provider>
  );
}
