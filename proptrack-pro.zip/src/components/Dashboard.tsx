import React, { useState, useEffect } from 'react';
import { 
  getProperties, 
  getExpenses, 
  getIncome, 
  getTenants,
  addProperty, 
  addExpense, 
  addIncome,
  addTenant,
  updateProperty,
  deleteProperty,
  updateExpense,
  deleteExpense,
  updateIncome,
  deleteIncome,
  updateTenant,
  deleteTenant,
  getMaintenance,
  addMaintenance,
  updateMaintenance,
  deleteMaintenance,
  getDocuments,
  addDocument,
  deleteDocument
} from '../services/firestore';
import { Property, Expense, Income, Tenant, Frequency, Maintenance, DocumentMetadata } from '../types';
import { formatCurrency, cn, calculateMonthlyAmount, calculateMortgagePayment } from '../lib/utils';
import { Plus, TrendingUp, TrendingDown, Home, DollarSign, PieChart, ArrowRight, Edit2, Trash2, Users, Activity, CreditCard, Wrench, FileText, Calendar, Clock, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function Dashboard() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [income, setIncome] = useState<Income[]>([]);
  const [showAddProperty, setShowAddProperty] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [period, setPeriod] = useState<'this-month' | 'last-month' | 'ytd' | 'all'>('all');

  useEffect(() => {
    const unsubProps = getProperties(setProperties);
    const unsubExpenses = getExpenses(null, setExpenses);
    const unsubIncome = getIncome(null, setIncome);
    return () => {
      unsubProps();
      unsubExpenses();
      unsubIncome();
    };
  }, []);

  const filteredIncome = income.filter(inc => {
    if (period === 'all') return true;
    const date = new Date(inc.date);
    const now = new Date();
    if (period === 'this-month') return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
    if (period === 'last-month') {
      const lastMonth = new Date();
      lastMonth.setMonth(now.getMonth() - 1);
      return date.getMonth() === lastMonth.getMonth() && date.getFullYear() === lastMonth.getFullYear();
    }
    if (period === 'ytd') return date.getFullYear() === now.getFullYear();
    return true;
  });

  const filteredExpenses = expenses.filter(exp => {
    if (period === 'all') return true;
    const date = new Date(exp.date);
    const now = new Date();
    if (period === 'this-month') return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
    if (period === 'last-month') {
      const lastMonth = new Date();
      lastMonth.setMonth(now.getMonth() - 1);
      return date.getMonth() === lastMonth.getMonth() && date.getFullYear() === lastMonth.getFullYear();
    }
    if (period === 'ytd') return date.getFullYear() === now.getFullYear();
    return true;
  });

  const totalMortgagePayments = properties.reduce((sum, p) => {
    if (p.mortgagePrincipal && p.mortgageInterestRate && p.mortgageTermYears) {
      return sum + calculateMortgagePayment(p.mortgagePrincipal, p.mortgageInterestRate, p.mortgageTermYears);
    }
    return sum;
  }, 0);

  const totalPropertyFixedExpenses = properties.reduce((sum, p) => {
    return sum + (p.annualTax / 12) + (p.annualInsurance / 12);
  }, 0);

  const totalIncome = filteredIncome.reduce((sum, inc) => sum + calculateMonthlyAmount(inc.amount, inc.frequency), 0);
  const totalExpenses = filteredExpenses.reduce((sum, exp) => sum + calculateMonthlyAmount(exp.amount, exp.frequency), 0) + totalMortgagePayments + totalPropertyFixedExpenses;
  const netProfit = totalIncome - totalExpenses;

  const occupiedProperties = properties.filter(p => p.status === 'occupied').length;
  const occupancyRate = properties.length > 0 ? (occupiedProperties / properties.length) * 100 : 0;

  const periodLabel = period === 'all' ? 'Monthly' : period === 'this-month' ? 'This Month' : period === 'last-month' ? 'Last Month' : 'YTD';

  return (
    <div className="space-y-12">
      {/* Period Selector */}
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-serif">Portfolio Overview</h2>
        <div className="flex bg-white rounded-full p-1 border border-black/5 shadow-sm">
          {[
            { id: 'all', label: 'All Time' },
            { id: 'this-month', label: 'This Month' },
            { id: 'last-month', label: 'Last Month' },
            { id: 'ytd', label: 'YTD' }
          ].map((p) => (
            <button
              key={p.id}
              onClick={() => setPeriod(p.id as any)}
              className={cn(
                "px-6 py-2 rounded-full text-[10px] uppercase tracking-widest font-bold transition-all",
                period === p.id ? "bg-[#5A5A40] text-white" : "text-[#1A1A1A]/40 hover:text-[#1A1A1A]"
              )}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Header Stats */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">Total Portfolio Value</span>
            <PieChart size={16} className="text-[#1A1A1A]/20" />
          </div>
          <p className="text-4xl font-serif">{formatCurrency(properties.reduce((sum, p) => sum + p.purchasePrice, 0))}</p>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#1A1A1A]/40">
            <Home size={12} />
            <span>{properties.length} Active Properties</span>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">Occupancy Rate</span>
            <Users size={16} className="text-[#5A5A40]/50" />
          </div>
          <p className="text-4xl font-serif">{occupancyRate.toFixed(1)}%</p>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#1A1A1A]/40">
            <div className="w-2 h-2 rounded-full bg-[#5A5A40]" />
            <span>{occupiedProperties} of {properties.length} Units Occupied</span>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">{periodLabel} Cash Flow</span>
            <Activity size={16} className={cn(netProfit >= 0 ? "text-green-500/50" : "text-red-500/50")} />
          </div>
          <p className={cn("text-4xl font-serif", netProfit >= 0 ? "text-green-600" : "text-red-600")}>
            {formatCurrency(netProfit)}
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#1A1A1A]/40">
            <TrendingUp size={12} className={netProfit >= 0 ? "text-green-500" : "text-red-500"} />
            <span>Net {periodLabel} Profit</span>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">{periodLabel} Revenue</span>
            <TrendingUp size={16} className="text-green-500/50" />
          </div>
          <p className="text-4xl font-serif text-green-600">{formatCurrency(totalIncome)}</p>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#1A1A1A]/40">
            <DollarSign size={12} />
            <span>Total {periodLabel} Income</span>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">{periodLabel} Expenses</span>
            <CreditCard size={16} className="text-red-500/50" />
          </div>
          <p className="text-4xl font-serif text-red-600">{formatCurrency(totalExpenses)}</p>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#1A1A1A]/40">
            <TrendingDown size={12} className="text-red-500" />
            <span>Total {periodLabel} Outflow</span>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A]/40 font-bold">Net Profitability</span>
            <TrendingDown size={16} className={cn(netProfit >= 0 ? "text-green-500/50" : "text-red-500/50")} />
          </div>
          <p className={cn("text-4xl font-serif", netProfit >= 0 ? "text-[#1A1A1A]" : "text-red-600")}>
            {formatCurrency(netProfit)}
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#1A1A1A]/40">
            <div className={cn("w-2 h-2 rounded-full", netProfit >= 0 ? "bg-green-500" : "bg-red-500")} />
            <span>{netProfit >= 0 ? 'Profitable' : 'Loss'}</span>
          </div>
        </div>
      </section>

      {/* Properties Grid */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-2xl font-serif">Properties</h3>
          <button 
            onClick={() => setShowAddProperty(true)}
            className="bg-[#5A5A40] text-white rounded-full py-2 px-6 flex items-center gap-2 text-xs uppercase tracking-widest font-medium hover:bg-[#4A4A30] transition-all"
          >
            <Plus size={16} />
            Add Property
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.map((property) => (
            <PropertyCard 
              key={property.id} 
              property={property} 
              expenses={filteredExpenses.filter(e => e.propertyId === property.id)}
              income={filteredIncome.filter(i => i.propertyId === property.id)}
              onClick={() => setSelectedProperty(property)}
              onEdit={() => setEditingProperty(property)}
            />
          ))}
          {properties.length === 0 && (
            <div className="col-span-full py-20 text-center border-2 border-dashed border-black/5 rounded-[32px]">
              <p className="text-[#1A1A1A]/40 italic">No properties added yet. Start by adding your first investment.</p>
            </div>
          )}
        </div>
      </section>

      {/* Modals */}
      <AnimatePresence>
        {showAddProperty && (
          <AddPropertyModal onClose={() => setShowAddProperty(false)} />
        )}
        {editingProperty && (
          <AddPropertyModal property={editingProperty} onClose={() => setEditingProperty(null)} />
        )}
        {selectedProperty && (
          <PropertyDetailsModal 
            property={selectedProperty} 
            expenses={filteredExpenses.filter(e => e.propertyId === selectedProperty.id)}
            income={filteredIncome.filter(i => i.propertyId === selectedProperty.id)}
            onClose={() => setSelectedProperty(null)}
            onEdit={() => {
              setEditingProperty(selectedProperty);
              setSelectedProperty(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function PropertyCard({ property, expenses, income, onClick, onEdit }: { 
  property: Property, 
  expenses: Expense[], 
  income: Income[],
  onClick: () => void,
  onEdit: () => void,
  key?: string
}) {
  const mortgagePayment = property.mortgagePrincipal && property.mortgageInterestRate && property.mortgageTermYears
    ? calculateMortgagePayment(property.mortgagePrincipal, property.mortgageInterestRate, property.mortgageTermYears)
    : 0;
  const fixedExpenses = (property.annualTax / 12) + (property.annualInsurance / 12);

  const pIncome = income.reduce((sum, i) => sum + calculateMonthlyAmount(i.amount, i.frequency), 0);
  const pExpenses = expenses.reduce((sum, e) => sum + calculateMonthlyAmount(e.amount, e.frequency), 0) + mortgagePayment + fixedExpenses;
  const pProfit = pIncome - pExpenses;

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this property? This action cannot be undone.')) {
      await deleteProperty(property.id);
    }
  };

  return (
    <motion.div 
      layoutId={property.id}
      onClick={onClick}
      className="bg-white rounded-[32px] overflow-hidden border border-black/5 shadow-sm hover:shadow-md transition-all cursor-pointer group relative"
    >
      <div className="h-48 bg-[#E6E6E6] relative overflow-hidden">
        {property.photos?.[0] ? (
          <img src={property.photos[0]} alt={property.address} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-[#1A1A1A]/10">
            <Home size={48} />
          </div>
        )}
        <div className="absolute top-4 right-4 flex gap-2">
          <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
            {pProfit >= 0 ? 'Profitable' : 'Review'}
          </div>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onEdit();
            }}
            className="bg-white/90 backdrop-blur-sm p-1.5 rounded-full text-[#5A5A40] opacity-0 group-hover:opacity-100 transition-opacity hover:bg-[#F5F2ED]"
          >
            <Edit2 size={12} />
          </button>
          <button 
            onClick={handleDelete}
            className="bg-white/90 backdrop-blur-sm p-1.5 rounded-full text-red-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>
      <div className="p-8">
        <h4 className="text-lg font-serif mb-1 truncate">{property.name}</h4>
        <p className="text-[10px] text-[#1A1A1A]/40 uppercase tracking-widest mb-6 truncate">{property.address}</p>
        
        <div className="grid grid-cols-2 gap-4 pt-6 border-t border-black/5">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1">Monthly Income</p>
            <p className="font-medium text-green-600">{formatCurrency(pIncome)}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1">Net Profit</p>
            <p className={cn("font-medium", pProfit >= 0 ? "text-[#1A1A1A]" : "text-red-600")}>{formatCurrency(pProfit)}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function AddPropertyModal({ property, onClose }: { property?: Property, onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: property?.name || '',
    address: property?.address || '',
    type: property?.type || 'single' as any,
    units: property?.units?.toString() || '1',
    bedrooms: property?.bedrooms?.toString() || '0',
    bathrooms: property?.bathrooms?.toString() || '0',
    sqft: property?.sqft?.toString() || '0',
    purchasePrice: property?.purchasePrice?.toString() || '',
    purchaseDate: property?.purchaseDate || new Date().toISOString().split('T')[0],
    monthlyRent: property?.monthlyRent?.toString() || '0',
    securityDeposit: property?.securityDeposit?.toString() || '0',
    status: property?.status || 'vacant' as any,
    ownerName: property?.ownerName || '',
    annualTax: property?.annualTax?.toString() || '0',
    annualInsurance: property?.annualInsurance?.toString() || '0',
    tenantName: property?.tenantName || '',
    tenantEmail: property?.tenantEmail || '',
    tenantPhone: property?.tenantPhone || '',
    leaseStart: property?.leaseStart || '',
    leaseEnd: property?.leaseEnd || '',
    notes: property?.notes || '',
    mortgagePrincipal: property?.mortgagePrincipal?.toString() || '0',
    mortgageInterestRate: property?.mortgageInterestRate?.toString() || '0',
    mortgageTermYears: property?.mortgageTermYears?.toString() || '30',
    mortgageStartDate: property?.mortgageStartDate || ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      ...formData,
      units: Number(formData.units),
      bedrooms: Number(formData.bedrooms),
      bathrooms: Number(formData.bathrooms),
      sqft: Number(formData.sqft),
      purchasePrice: Number(formData.purchasePrice),
      monthlyRent: Number(formData.monthlyRent),
      securityDeposit: Number(formData.securityDeposit),
      annualTax: Number(formData.annualTax),
      annualInsurance: Number(formData.annualInsurance),
      mortgagePrincipal: Number(formData.mortgagePrincipal),
      mortgageInterestRate: Number(formData.mortgageInterestRate),
      mortgageTermYears: Number(formData.mortgageTermYears),
      mortgageStartDate: formData.mortgageStartDate,
      photos: property?.photos || []
    };

    if (property) {
      await updateProperty(property.id, data);
    } else {
      await addProperty(data);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[#1A1A1A]/40 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative bg-white w-full max-w-4xl max-h-[90vh] rounded-[32px] p-12 shadow-2xl overflow-y-auto custom-scrollbar"
      >
        <h3 className="text-3xl font-serif mb-8">{property ? 'Edit Property' : 'New Property'}</h3>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Property Name</label>
              <input name="name" required value={formData.name} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" placeholder="Sunset Villa" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Address</label>
              <input name="address" required value={formData.address} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" placeholder="123 Luxury Ave, City" />
            </div>
          </div>

          {/* Property Details */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Type</label>
              <select name="type" value={formData.type} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none">
                <option value="single">Single Family</option>
                <option value="duplex">Duplex</option>
                <option value="mobile_home">Mobile Home</option>
                <option value="apartment_complex">Apartment Complex</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Units</label>
              <input name="units" type="number" value={formData.units} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Status</label>
              <select name="status" value={formData.status} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none">
                <option value="vacant">Vacant</option>
                <option value="occupied">Occupied</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Owner Name</label>
              <input name="ownerName" value={formData.ownerName} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" placeholder="John Doe" />
            </div>
          </div>

          {/* Specs */}
          <div className="grid grid-cols-3 gap-6">
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Bedrooms</label>
              <input name="bedrooms" type="number" value={formData.bedrooms} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Bathrooms</label>
              <input name="bathrooms" type="number" step="0.5" value={formData.bathrooms} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Sq Footage</label>
              <input name="sqft" type="number" value={formData.sqft} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
          </div>

          {/* Financials */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Purchase Price</label>
              <input name="purchasePrice" type="number" required value={formData.purchasePrice} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" placeholder="500000" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Purchase Date</label>
              <input name="purchaseDate" type="date" value={formData.purchaseDate} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Monthly Rent</label>
              <input name="monthlyRent" type="number" value={formData.monthlyRent} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Security Deposit</label>
              <input name="securityDeposit" type="number" value={formData.securityDeposit} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Annual Tax</label>
              <input name="annualTax" type="number" value={formData.annualTax} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Annual Insurance</label>
              <input name="annualInsurance" type="number" value={formData.annualInsurance} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
            </div>
          </div>

          {/* Tenant Info */}
          <div className="pt-8 border-t border-black/5">
            <h4 className="text-sm uppercase tracking-widest font-bold mb-6">Mortgage Info (Optional)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Principal Amount</label>
                <input name="mortgagePrincipal" type="number" value={formData.mortgagePrincipal} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" placeholder="0" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Interest Rate (%)</label>
                <input name="mortgageInterestRate" type="number" step="0.01" value={formData.mortgageInterestRate} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" placeholder="0.00" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Term (Years)</label>
                <input name="mortgageTermYears" type="number" value={formData.mortgageTermYears} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Start Date</label>
                <input name="mortgageStartDate" type="date" value={formData.mortgageStartDate} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
            </div>
          </div>

          {/* Tenant Info */}
          <div className="pt-8 border-t border-black/5">
            <h4 className="text-sm uppercase tracking-widest font-bold mb-6">Initial Tenant & Lease (Optional)</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Tenant Name</label>
                <input name="tenantName" value={formData.tenantName} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Tenant Email</label>
                <input name="tenantEmail" type="email" value={formData.tenantEmail} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Tenant Phone</label>
                <input name="tenantPhone" value={formData.tenantPhone} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Lease Start</label>
                <input name="leaseStart" type="date" value={formData.leaseStart} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Lease End</label>
                <input name="leaseEnd" type="date" value={formData.leaseEnd} onChange={handleChange} className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none" />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Additional Notes</label>
            <textarea 
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              className="w-full bg-[#F5F2ED] border-none rounded-2xl px-6 py-4 outline-none h-32 resize-none"
              placeholder="Any other details..."
            />
          </div>

          <div className="pt-4 flex gap-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 border border-black/10 rounded-full py-4 text-xs uppercase tracking-widest font-bold hover:bg-[#F5F2ED] transition-all"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 bg-[#5A5A40] text-white rounded-full py-4 text-xs uppercase tracking-widest font-bold hover:bg-[#4A4A30] transition-all"
            >
              Create Property
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function PropertyDetailsModal({ property, expenses, income, onClose, onEdit }: { 
  property: Property, 
  expenses: Expense[], 
  income: Income[],
  onClose: () => void,
  onEdit: () => void
}) {
  const [activeTab, setActiveTab] = useState<'overview' | 'income' | 'expenses' | 'tenants' | 'maintenance' | 'documents'>('overview');
  const [showAddIncome, setShowAddIncome] = useState(false);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [showAddTenant, setShowAddTenant] = useState(false);
  const [showAddMaintenance, setShowAddMaintenance] = useState(false);
  const [showAddDocument, setShowAddDocument] = useState(false);
  const [editingIncome, setEditingIncome] = useState<Income | null>(null);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [editingMaintenance, setEditingMaintenance] = useState<Maintenance | null>(null);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [maintenance, setMaintenance] = useState<Maintenance[]>([]);
  const [documents, setDocuments] = useState<DocumentMetadata[]>([]);

  useEffect(() => {
    if (property.id) {
      const unsubTenants = getTenants(property.id, setTenants);
      const unsubMaintenance = getMaintenance(property.id, setMaintenance);
      const unsubDocuments = getDocuments(property.id, setDocuments);
      return () => {
        unsubTenants();
        unsubMaintenance();
        unsubDocuments();
      };
    }
  }, [property.id]);

  const mortgagePayment = property.mortgagePrincipal && property.mortgageInterestRate && property.mortgageTermYears
    ? calculateMortgagePayment(property.mortgagePrincipal, property.mortgageInterestRate, property.mortgageTermYears)
    : 0;
  const fixedExpenses = (property.annualTax / 12) + (property.annualInsurance / 12);

  const pIncome = income.reduce((sum, i) => sum + calculateMonthlyAmount(i.amount, i.frequency), 0);
  const pExpenses = expenses.reduce((sum, e) => sum + calculateMonthlyAmount(e.amount, e.frequency), 0) + mortgagePayment + fixedExpenses;
  const pProfit = pIncome - pExpenses;

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this property? This action cannot be undone.')) {
      await deleteProperty(property.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[#1A1A1A]/40 backdrop-blur-sm"
      />
      <motion.div 
        layoutId={property.id}
        className="relative bg-white w-full max-w-4xl max-h-[90vh] rounded-[32px] overflow-hidden shadow-2xl flex flex-col"
      >
        <div className="h-48 bg-[#5A5A40] p-12 flex items-end justify-between relative">
          <div className="absolute top-8 right-8 flex gap-4">
            <button onClick={onEdit} className="text-white/60 hover:text-white transition-colors">
              <Edit2 size={20} />
            </button>
            <button onClick={handleDelete} className="text-white/60 hover:text-red-400 transition-colors">
              <Trash2 size={20} />
            </button>
            <button onClick={onClose} className="text-white/60 hover:text-white transition-colors">
              <Plus size={24} className="rotate-45" />
            </button>
          </div>
          <div className="text-white">
            <h3 className="text-3xl font-serif mb-2">{property.name}</h3>
            <p className="text-xs uppercase tracking-[0.2em] opacity-60">{property.address}</p>
          </div>
          <div className="text-right text-white">
            <p className="text-[10px] uppercase tracking-widest opacity-60 mb-1">Monthly Rent</p>
            <p className="text-3xl font-serif">{formatCurrency(property.monthlyRent || 0)}</p>
          </div>
        </div>

        <div className="flex border-b border-black/5 px-12 overflow-x-auto no-scrollbar">
          {['overview', 'income', 'expenses', 'tenants', 'maintenance', 'documents'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={cn(
                "py-6 px-4 text-[10px] uppercase tracking-widest font-bold border-b-2 transition-all whitespace-nowrap",
                activeTab === tab ? "border-[#5A5A40] text-[#1A1A1A]" : "border-transparent text-[#1A1A1A]/40"
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-12 custom-scrollbar">
          {activeTab === 'overview' && (
            <div className="space-y-12">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Type</p>
                  <p className="text-sm font-medium capitalize">{property.type.replace('_', ' ')}</p>
                </div>
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Status</p>
                  <p className="text-sm font-medium capitalize">{property.status}</p>
                </div>
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Units</p>
                  <p className="text-sm font-medium">{property.units}</p>
                </div>
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Sq Footage</p>
                  <p className="text-sm font-medium">{property.sqft} sqft</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Purchase Price</p>
                  <p className="text-sm font-medium">{formatCurrency(property.purchasePrice)}</p>
                </div>
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Purchase Date</p>
                  <p className="text-sm font-medium">{property.purchaseDate}</p>
                </div>
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Annual Tax</p>
                  <p className="text-sm font-medium">{formatCurrency(property.annualTax || 0)}</p>
                </div>
                <div className="bg-[#F5F2ED] p-6 rounded-2xl">
                  <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Annual Insurance</p>
                  <p className="text-sm font-medium">{formatCurrency(property.annualInsurance || 0)}</p>
                </div>
              </div>

              {property.mortgagePrincipal && (
                <div className="space-y-6">
                  <h4 className="text-sm uppercase tracking-widest font-bold">Mortgage Details</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div className="bg-[#F5F2ED] p-6 rounded-2xl border border-[#5A5A40]/10">
                      <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Principal</p>
                      <p className="text-sm font-medium">{formatCurrency(property.mortgagePrincipal)}</p>
                    </div>
                    <div className="bg-[#F5F2ED] p-6 rounded-2xl border border-[#5A5A40]/10">
                      <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Interest Rate</p>
                      <p className="text-sm font-medium">{property.mortgageInterestRate}%</p>
                    </div>
                    <div className="bg-[#F5F2ED] p-6 rounded-2xl border border-[#5A5A40]/10">
                      <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Term</p>
                      <p className="text-sm font-medium">{property.mortgageTermYears} Years</p>
                    </div>
                    <div className="bg-[#F5F2ED] p-6 rounded-2xl border border-[#5A5A40]/10">
                      <p className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2">Monthly Payment</p>
                      <p className="text-sm font-bold text-[#5A5A40]">{formatCurrency(mortgagePayment)}</p>
                    </div>
                  </div>
                </div>
              )}
              <div>
                <h4 className="text-sm uppercase tracking-widest font-bold mb-4">Notes</h4>
                <p className="text-[#1A1A1A]/60 leading-relaxed italic">{property.notes || 'No notes available for this property.'}</p>
              </div>
            </div>
          )}

          {activeTab === 'income' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h4 className="text-sm uppercase tracking-widest font-bold">Income History</h4>
                <button 
                  onClick={() => setShowAddIncome(true)}
                  className="text-[#5A5A40] text-[10px] uppercase tracking-widest font-bold flex items-center gap-1 hover:underline"
                >
                  <Plus size={12} /> Add Entry
                </button>
              </div>
              <div className="space-y-4">
                {income.map(item => (
                  <div key={item.id} className="flex items-center justify-between p-4 bg-[#F5F2ED] rounded-xl group">
                    <div>
                      <p className="text-sm font-medium">{item.source.charAt(0).toUpperCase() + item.source.slice(1)} — <span className="text-[#1A1A1A]/40 text-[10px] uppercase tracking-widest">{item.frequency}</span></p>
                      <p className="text-[10px] text-[#1A1A1A]/40">{item.date}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-serif text-green-600">{formatCurrency(item.amount)}</p>
                        <p className={cn("text-[8px] uppercase tracking-widest font-bold", item.status === 'paid' ? 'text-green-500' : 'text-red-500')}>
                          {item.status}
                        </p>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setEditingIncome(item)} className="p-1 text-[#5A5A40] hover:bg-white rounded-full transition-colors">
                          <Edit2 size={12} />
                        </button>
                        <button onClick={() => deleteIncome(item.id)} className="p-1 text-red-500 hover:bg-red-50 rounded-full transition-colors">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {income.length === 0 && <p className="text-center py-8 text-[#1A1A1A]/40 italic">No income recorded.</p>}
              </div>
            </div>
          )}

          {activeTab === 'expenses' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h4 className="text-sm uppercase tracking-widest font-bold">Expense History</h4>
                <button 
                  onClick={() => setShowAddExpense(true)}
                  className="text-[#5A5A40] text-[10px] uppercase tracking-widest font-bold flex items-center gap-1 hover:underline"
                >
                  <Plus size={12} /> Add Entry
                </button>
              </div>
              <div className="space-y-4">
                {expenses.map(item => (
                  <div key={item.id} className="flex items-center justify-between p-4 bg-[#F5F2ED] rounded-xl group">
                    <div>
                      <p className="text-sm font-medium">{item.category.charAt(0).toUpperCase() + item.category.slice(1)} — <span className="text-[#1A1A1A]/40 text-[10px] uppercase tracking-widest">{item.frequency}</span></p>
                      <p className="text-[10px] text-[#1A1A1A]/40">{item.date} — {item.description}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-serif text-red-600">{formatCurrency(item.amount)}</p>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setEditingExpense(item)} className="p-1 text-[#5A5A40] hover:bg-white rounded-full transition-colors">
                          <Edit2 size={12} />
                        </button>
                        <button onClick={() => deleteExpense(item.id)} className="p-1 text-red-500 hover:bg-red-50 rounded-full transition-colors">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {expenses.length === 0 && <p className="text-center py-8 text-[#1A1A1A]/40 italic">No expenses recorded.</p>}
              </div>
            </div>
          )}

          {activeTab === 'maintenance' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h4 className="text-sm uppercase tracking-widest font-bold">Maintenance Log</h4>
                <button 
                  onClick={() => setShowAddMaintenance(true)}
                  className="text-[#5A5A40] text-[10px] uppercase tracking-widest font-bold flex items-center gap-1 hover:underline"
                >
                  <Plus size={12} /> Add Request
                </button>
              </div>
              <div className="space-y-4">
                {maintenance.map(item => (
                  <div key={item.id} className="p-6 bg-[#F5F2ED] rounded-2xl border border-black/5 group relative">
                    <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => setEditingMaintenance(item)} className="p-1.5 text-[#5A5A40] hover:bg-white rounded-full transition-colors">
                        <Edit2 size={12} />
                      </button>
                      <button onClick={() => deleteMaintenance(item.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-full transition-colors">
                        <Trash2 size={12} />
                      </button>
                    </div>
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <p className="text-lg font-serif mb-1">{item.title}</p>
                        <div className="flex items-center gap-2 text-[10px] text-[#1A1A1A]/40 uppercase tracking-widest">
                          <Calendar size={10} />
                          <span>{item.date}</span>
                          <span>•</span>
                          <span className="capitalize">{item.category}</span>
                        </div>
                      </div>
                      <div className={cn(
                        "px-3 py-1 rounded-full text-[8px] font-bold uppercase tracking-widest flex items-center gap-1",
                        item.status === 'completed' ? "bg-green-100 text-green-600" : 
                        item.status === 'in-progress' ? "bg-blue-100 text-blue-600" : "bg-orange-100 text-orange-600"
                      )}>
                        {item.status === 'completed' ? <CheckCircle2 size={10} /> : 
                         item.status === 'in-progress' ? <Clock size={10} /> : <AlertCircle size={10} />}
                        {item.status.replace('-', ' ')}
                      </div>
                    </div>
                    <p className="text-sm text-[#1A1A1A]/60 mb-4">{item.description}</p>
                    <div className="flex justify-between items-center pt-4 border-t border-black/5">
                      <div>
                        <p className="text-[8px] uppercase tracking-widest text-[#1A1A1A]/40">Cost</p>
                        <p className="text-sm font-medium">{formatCurrency(item.cost || 0)}</p>
                      </div>
                      {item.vendor && (
                        <div className="text-right">
                          <p className="text-[8px] uppercase tracking-widest text-[#1A1A1A]/40">Vendor</p>
                          <p className="text-sm font-medium">{item.vendor}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {maintenance.length === 0 && <p className="text-center py-8 text-[#1A1A1A]/40 italic">No maintenance requests recorded.</p>}
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h4 className="text-sm uppercase tracking-widest font-bold">Property Documents</h4>
                <button 
                  onClick={() => setShowAddDocument(true)}
                  className="text-[#5A5A40] text-[10px] uppercase tracking-widest font-bold flex items-center gap-1 hover:underline"
                >
                  <Plus size={12} /> Add Document
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {documents.map(doc => (
                  <div key={doc.id} className="p-4 bg-[#F5F2ED] rounded-xl border border-black/5 flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white rounded-lg text-[#5A5A40]">
                        <FileText size={20} />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{doc.name}</p>
                        <p className="text-[10px] text-[#1A1A1A]/40 uppercase tracking-widest">{doc.type}</p>
                      </div>
                    </div>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <a href={doc.url} target="_blank" rel="noopener noreferrer" className="p-1.5 text-[#5A5A40] hover:bg-white rounded-full transition-colors">
                        <ArrowRight size={14} />
                      </a>
                      <button onClick={() => deleteDocument(doc.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-full transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
                {documents.length === 0 && <p className="col-span-full text-center py-8 text-[#1A1A1A]/40 italic">No documents uploaded.</p>}
              </div>
            </div>
          )}
        </div>

        {/* Nested Modals */}
        <AnimatePresence>
          {(editingIncome || showAddIncome) && (
            <AddIncomeModal 
              propertyId={property.id} 
              income={editingIncome || undefined}
              onClose={() => {
                setShowAddIncome(false);
                setEditingIncome(null);
              }} 
            />
          )}
          {(editingExpense || showAddExpense) && (
            <AddExpenseModal 
              propertyId={property.id} 
              expense={editingExpense || undefined}
              onClose={() => {
                setShowAddExpense(false);
                setEditingExpense(null);
              }} 
            />
          )}
          {(editingTenant || showAddTenant) && (
            <AddTenantModal 
              propertyId={property.id} 
              tenant={editingTenant || undefined}
              onClose={() => {
                setShowAddTenant(false);
                setEditingTenant(null);
              }} 
            />
          )}
          {(editingMaintenance || showAddMaintenance) && (
            <AddMaintenanceModal 
              propertyId={property.id} 
              maintenance={editingMaintenance || undefined}
              onClose={() => {
                setShowAddMaintenance(false);
                setEditingMaintenance(null);
              }} 
            />
          )}
          {showAddDocument && (
            <AddDocumentModal 
              propertyId={property.id} 
              onClose={() => setShowAddDocument(false)} 
            />
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function AddDocumentModal({ propertyId, onClose }: { propertyId: string, onClose: () => void }) {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [type, setType] = useState<any>('lease');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await addDocument({
      propertyId,
      name,
      url,
      type
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-[#1A1A1A]/20 backdrop-blur-sm" />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-white w-full max-w-md rounded-[32px] p-10 shadow-2xl">
        <h4 className="text-2xl font-serif mb-6">Add Document</h4>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Document Name</label>
            <input required value={name} onChange={e => setName(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="e.g. Lease Agreement 2024" />
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Document URL</label>
            <input required type="url" value={url} onChange={e => setUrl(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="https://..." />
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Type</label>
            <select value={type} onChange={e => setType(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
              <option value="lease">Lease</option>
              <option value="insurance">Insurance</option>
              <option value="tax">Tax Document</option>
              <option value="mortgage">Mortgage</option>
              <option value="other">Other</option>
            </select>
          </div>
          <button type="submit" className="w-full bg-[#5A5A40] text-white rounded-full py-3 text-[10px] uppercase tracking-widest font-bold mt-4">Save Document</button>
        </form>
      </motion.div>
    </div>
  );
}

function AddMaintenanceModal({ propertyId, maintenance, onClose }: { propertyId: string, maintenance?: Maintenance, onClose: () => void }) {
  const [title, setTitle] = useState(maintenance?.title || '');
  const [description, setDescription] = useState(maintenance?.description || '');
  const [category, setCategory] = useState<any>(maintenance?.category || 'repair');
  const [status, setStatus] = useState<any>(maintenance?.status || 'pending');
  const [cost, setCost] = useState(maintenance?.cost?.toString() || '');
  const [vendor, setVendor] = useState(maintenance?.vendor || '');
  const [date, setDate] = useState(maintenance?.date || new Date().toISOString().split('T')[0]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      propertyId,
      title,
      description,
      category,
      status,
      cost: Number(cost),
      vendor,
      date,
      photos: maintenance?.photos || []
    };

    if (maintenance) {
      await updateMaintenance(maintenance.id, data);
    } else {
      await addMaintenance(data);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-[#1A1A1A]/20 backdrop-blur-sm" />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-white w-full max-w-md rounded-[32px] p-10 shadow-2xl">
        <h4 className="text-2xl font-serif mb-6">{maintenance ? 'Edit Request' : 'Maintenance Request'}</h4>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Title</label>
            <input required value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="e.g. Leaking Faucet" />
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none h-24 resize-none" placeholder="Details about the issue..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Category</label>
              <select value={category} onChange={e => setCategory(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
                <option value="repair">Repair</option>
                <option value="improvement">Improvement</option>
                <option value="inspection">Inspection</option>
                <option value="emergency">Emergency</option>
              </select>
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Status</label>
              <select value={status} onChange={e => setStatus(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Cost</label>
              <input type="number" value={cost} onChange={e => setCost(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Date</label>
              <input required type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Vendor (Optional)</label>
            <input value={vendor} onChange={e => setVendor(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="Company Name" />
          </div>
          <button type="submit" className="w-full bg-[#5A5A40] text-white rounded-full py-3 text-[10px] uppercase tracking-widest font-bold mt-4">Save Request</button>
        </form>
      </motion.div>
    </div>
  );
}

function AddTenantModal({ propertyId, tenant, onClose }: { propertyId: string, tenant?: Tenant, onClose: () => void }) {
  const [name, setName] = useState(tenant?.name || '');
  const [email, setEmail] = useState(tenant?.email || '');
  const [rent, setRent] = useState(tenant?.monthlyRent?.toString() || '');
  const [dueDate, setDueDate] = useState(tenant?.rentDueDate?.toString() || '1');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      propertyId,
      name,
      email,
      monthlyRent: Number(rent),
      rentDueDate: Number(dueDate)
    };

    if (tenant) {
      await updateTenant(tenant.id, data);
    } else {
      await addTenant(data);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-[#1A1A1A]/20 backdrop-blur-sm" />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-white w-full max-w-md rounded-[32px] p-10 shadow-2xl">
        <h4 className="text-2xl font-serif mb-6">Add Tenant</h4>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Name</label>
            <input required value={name} onChange={e => setName(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="Tenant Name" />
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="email@example.com" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Monthly Rent</label>
              <input required type="number" value={rent} onChange={e => setRent(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Due Day</label>
              <input required type="number" min="1" max="31" value={dueDate} onChange={e => setDueDate(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" />
            </div>
          </div>
          <button type="submit" className="w-full bg-[#5A5A40] text-white rounded-full py-3 text-[10px] uppercase tracking-widest font-bold mt-4">Add Tenant</button>
        </form>
      </motion.div>
    </div>
  );
}

function AddIncomeModal({ propertyId, income, onClose }: { propertyId: string, income?: Income, onClose: () => void }) {
  const [amount, setAmount] = useState(income?.amount?.toString() || '');
  const [source, setSource] = useState<any>(income?.source || 'rent');
  const [status, setStatus] = useState<any>(income?.status || 'paid');
  const [frequency, setFrequency] = useState<Frequency>(income?.frequency || 'monthly');
  const [date, setDate] = useState(income?.date || new Date().toISOString().split('T')[0]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      propertyId,
      amount: Number(amount),
      source,
      status,
      frequency,
      date
    };

    if (income) {
      await updateIncome(income.id, data);
    } else {
      await addIncome(data);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-[#1A1A1A]/20 backdrop-blur-sm" />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-white w-full max-w-md rounded-[32px] p-10 shadow-2xl">
        <h4 className="text-2xl font-serif mb-6">{income ? 'Edit Income' : 'Record Income'}</h4>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Amount</label>
              <input required type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Date</label>
              <input required type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Source</label>
              <select value={source} onChange={e => setSource(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
                <option value="rent">Rent</option>
                <option value="parking">Parking</option>
                <option value="laundry">Laundry</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Frequency</label>
              <select value={frequency} onChange={e => setFrequency(e.target.value as Frequency)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
                <option value="one-time">One-time</option>
                <option value="weekly">Weekly</option>
                <option value="bi-weekly">Bi-weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Status</label>
            <select value={status} onChange={e => setStatus(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
              <option value="paid">Paid</option>
              <option value="late">Late</option>
              <option value="missed">Missed</option>
            </select>
          </div>
          <button type="submit" className="w-full bg-[#5A5A40] text-white rounded-full py-3 text-[10px] uppercase tracking-widest font-bold mt-4">Save Entry</button>
        </form>
      </motion.div>
    </div>
  );
}

function AddExpenseModal({ propertyId, expense, onClose }: { propertyId: string, expense?: Expense, onClose: () => void }) {
  const [amount, setAmount] = useState(expense?.amount?.toString() || '');
  const [category, setCategory] = useState<any>(expense?.category || 'repairs');
  const [description, setDescription] = useState(expense?.description || '');
  const [frequency, setFrequency] = useState<Frequency>(expense?.frequency || 'one-time');
  const [date, setDate] = useState(expense?.date || new Date().toISOString().split('T')[0]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      propertyId,
      amount: Number(amount),
      category,
      description,
      frequency,
      date
    };

    if (expense) {
      await updateExpense(expense.id, data);
    } else {
      await addExpense(data);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-[#1A1A1A]/20 backdrop-blur-sm" />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative bg-white w-full max-w-md rounded-[32px] p-10 shadow-2xl">
        <h4 className="text-2xl font-serif mb-6">{expense ? 'Edit Expense' : 'Record Expense'}</h4>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Amount</label>
              <input required type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Date</label>
              <input required type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Category</label>
              <select value={category} onChange={e => setCategory(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
                <option value="repairs">Repairs</option>
                <option value="utilities">Utilities</option>
                <option value="taxes">Taxes</option>
                <option value="insurance">Insurance</option>
                <option value="management">Management</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Frequency</label>
              <select value={frequency} onChange={e => setFrequency(e.target.value as Frequency)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none">
                <option value="one-time">One-time</option>
                <option value="weekly">Weekly</option>
                <option value="bi-weekly">Bi-weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-[8px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Description</label>
            <input required value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-[#F5F2ED] border-none rounded-xl px-4 py-3 outline-none" placeholder="What was this for?" />
          </div>
          <button type="submit" className="w-full bg-[#5A5A40] text-white rounded-full py-3 text-[10px] uppercase tracking-widest font-bold mt-4">Save Entry</button>
        </form>
      </motion.div>
    </div>
  );
}
