import React, { useState, useEffect } from 'react';
import { getDocuments, deleteDocument } from '../services/firestore';
import { DocumentMetadata } from '../types';
import { FileText, Trash2, ExternalLink, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function DocumentsView() {
  const [documents, setDocuments] = useState<DocumentMetadata[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsub = getDocuments(null, setDocuments);
    return () => unsub();
  }, []);

  const filteredDocuments = documents.filter(doc => 
    doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this document?')) {
      try {
        await deleteDocument(id);
      } catch (error) {
        console.error('Delete failed', error);
      }
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-serif">Global Documents</h2>
        <div className="relative">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#1A1A1A]/40" />
          <input 
            type="text" 
            placeholder="Search documents..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 pr-6 py-3 bg-white border border-black/5 rounded-full text-sm focus:outline-none focus:border-[#5A5A40] w-64 shadow-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence>
          {filteredDocuments.map(doc => (
            <motion.div 
              key={doc.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm group relative"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="w-12 h-12 bg-[#5A5A40]/5 rounded-2xl flex items-center justify-center text-[#5A5A40]">
                  <FileText size={24} />
                </div>
                <div className="flex gap-2">
                  <a 
                    href={doc.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 text-[#1A1A1A]/40 hover:text-[#5A5A40] transition-colors"
                  >
                    <ExternalLink size={16} />
                  </a>
                  <button 
                    onClick={() => handleDelete(doc.id)}
                    className="p-2 text-[#1A1A1A]/40 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <h4 className="text-lg font-serif mb-1">{doc.name}</h4>
              <p className="text-[10px] text-[#1A1A1A]/40 uppercase tracking-widest mb-4">{doc.type}</p>
              <p className="text-xs text-[#1A1A1A]/60 italic">{new Date(doc.createdAt).toLocaleDateString()}</p>
            </motion.div>
          ))}
        </AnimatePresence>

        {filteredDocuments.length === 0 && (
          <div className="col-span-full text-center py-24 bg-white rounded-[32px] border border-black/5 shadow-sm">
            <FileText size={48} className="mx-auto mb-6 text-[#1A1A1A]/20" />
            <h3 className="text-xl font-serif mb-2">No Documents Found</h3>
            <p className="text-[#1A1A1A]/60 italic">Upload documents from a property details page to see them here.</p>
          </div>
        )}
      </div>
    </div>
  );
}
