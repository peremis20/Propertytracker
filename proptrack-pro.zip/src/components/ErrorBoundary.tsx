import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      let errorMessage = "An unexpected error occurred.";
      let isPermissionError = false;

      try {
        if (this.state.error?.message) {
          const parsed = JSON.parse(this.state.error.message);
          if (parsed.error && parsed.error.includes('permission')) {
            isPermissionError = true;
            errorMessage = "You don't have permission to perform this action or access this data.";
          }
        }
      } catch (e) {
        errorMessage = this.state.error?.message || errorMessage;
      }

      return (
        <div className="min-h-screen bg-[#F5F2ED] flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white rounded-[32px] p-12 shadow-sm border border-black/5 text-center">
            <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center text-red-500 mx-auto mb-6">
              <AlertCircle size={32} />
            </div>
            <h1 className="text-2xl font-serif mb-4 text-[#1A1A1A]">
              {isPermissionError ? "Access Denied" : "Something went wrong"}
            </h1>
            <p className="text-[#1A1A1A]/60 mb-8 italic">
              {errorMessage}
            </p>
            <button 
              onClick={this.handleReset}
              className="w-full bg-[#5A5A40] text-white rounded-full py-4 px-8 flex items-center justify-center gap-3 hover:bg-[#4A4A30] transition-colors font-medium tracking-wide"
            >
              <RefreshCw size={20} />
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
