import React, { useState, useEffect } from 'react';
import { useAuth } from './Auth';
import { getUsers, updateUserProfile, getInvites, addInvite, deleteInvite } from '../services/firestore';
import { UserProfile, UserRole } from '../types';
import { User, Shield, Save, Check, AlertCircle, Loader2, Mail, Trash2, Plus } from 'lucide-react';
import { motion } from 'framer-motion';

export function SettingsView() {
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [invites, setInvites] = useState<{ id: string; email: string; role: UserRole }[]>([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<UserRole>('viewer');
  const [isInviting, setIsInviting] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    if (profile?.role === 'admin') {
      const unsubUsers = getUsers(setUsers);
      const unsubInvites = getInvites(setInvites);
      return () => {
        unsubUsers();
        unsubInvites();
      };
    }
  }, [profile?.role]);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    setIsInviting(true);
    try {
      await addInvite(inviteEmail, inviteRole);
      setInviteEmail('');
      setInviteRole('viewer');
    } catch (error) {
      console.error('Invite failed', error);
    } finally {
      setIsInviting(false);
    }
  };

  const handleRevokeInvite = async (email: string) => {
    try {
      await deleteInvite(email);
    } catch (error) {
      console.error('Revoke failed', error);
    }
  };

  const handleUpdateProfile = async () => {
    if (!profile) return;
    setIsSaving(true);
    setSaveStatus('idle');
    try {
      await updateUserProfile(profile.uid, { displayName });
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (error) {
      console.error('Update failed', error);
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRoleChange = async (uid: string, newRole: UserRole) => {
    try {
      await updateUserProfile(uid, { role: newRole });
    } catch (error) {
      console.error('Role update failed', error);
    }
  };

  return (
    <div className="space-y-12">
      <div>
        <h1 className="text-4xl font-serif text-[#1A1A1A] mb-2">Settings</h1>
        <p className="text-[#1A1A1A]/60 italic">Manage your profile and application preferences.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Profile Settings */}
        <div className="lg:col-span-1 space-y-8">
          <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-[#5A5A40]/5 rounded-2xl flex items-center justify-center text-[#5A5A40]">
                <User size={24} />
              </div>
              <h2 className="text-xl font-serif">Profile</h2>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Email</label>
                <div className="px-4 py-3 bg-[#F5F2ED]/50 border border-black/5 rounded-2xl text-[#1A1A1A]/60 text-sm">
                  {profile?.email}
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-2 font-bold">Display Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full px-4 py-3 bg-white border border-black/5 rounded-2xl text-sm focus:outline-none focus:border-[#5A5A40] transition-colors"
                  placeholder="Enter your name"
                />
              </div>

              <button
                onClick={handleUpdateProfile}
                disabled={isSaving}
                className="w-full bg-[#5A5A40] text-white rounded-full py-4 px-8 flex items-center justify-center gap-3 hover:bg-[#4A4A30] transition-all disabled:opacity-50 font-medium tracking-wide"
              >
                {isSaving ? (
                  <Loader2 size={20} className="animate-spin" />
                ) : saveStatus === 'success' ? (
                  <Check size={20} />
                ) : saveStatus === 'error' ? (
                  <AlertCircle size={20} />
                ) : (
                  <Save size={20} />
                )}
                {isSaving ? 'Saving...' : saveStatus === 'success' ? 'Saved' : saveStatus === 'error' ? 'Error' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>

        {/* User Management (Admin Only) */}
        {profile?.role === 'admin' && (
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-[#5A5A40]/5 rounded-2xl flex items-center justify-center text-[#5A5A40]">
                  <Shield size={24} />
                </div>
                <h2 className="text-xl font-serif">User Management</h2>
              </div>

              {/* Invite Form */}
              <form onSubmit={handleInvite} className="mb-12 p-6 bg-[#F5F2ED]/50 rounded-2xl border border-black/5">
                <div className="flex items-center gap-4 mb-4">
                  <Mail size={18} className="text-[#5A5A40]" />
                  <h3 className="text-sm font-medium">Invite New User</h3>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <input
                    type="email"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    placeholder="Email address"
                    className="flex-1 px-4 py-2 bg-white border border-black/5 rounded-xl text-sm focus:outline-none focus:border-[#5A5A40]"
                    required
                  />
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value as UserRole)}
                    className="px-4 py-2 bg-white border border-black/5 rounded-xl text-sm focus:outline-none focus:border-[#5A5A40]"
                  >
                    <option value="viewer">Viewer</option>
                    <option value="manager">Manager</option>
                    <option value="admin">Admin</option>
                  </select>
                  <button
                    type="submit"
                    disabled={isInviting}
                    className="bg-[#5A5A40] text-white px-6 py-2 rounded-xl text-sm font-medium hover:bg-[#4A4A30] transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {isInviting ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
                    Invite
                  </button>
                </div>
              </form>

              {/* Pending Invites */}
              {invites.length > 0 && (
                <div className="mb-12">
                  <h3 className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 font-bold mb-4">Pending Invites</h3>
                  <div className="space-y-3">
                    {invites.map((invite) => (
                      <div key={invite.id} className="flex items-center justify-between p-4 bg-white border border-black/5 rounded-2xl group">
                        <div className="flex items-center gap-4">
                          <div className="w-8 h-8 rounded-full bg-[#5A5A40]/5 flex items-center justify-center text-[#5A5A40]">
                            <Mail size={14} />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{invite.email}</p>
                            <p className="text-[10px] uppercase tracking-tighter text-[#1A1A1A]/40">{invite.role}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleRevokeInvite(invite.email)}
                          className="p-2 text-[#1A1A1A]/20 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                          title="Revoke Invite"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <h3 className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 font-bold mb-4">Active Users</h3>
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b border-black/5">
                      <th className="pb-4 text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 font-bold">User</th>
                      <th className="pb-4 text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 font-bold">Email</th>
                      <th className="pb-4 text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 font-bold">Role</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black/5">
                    {users.map((u) => (
                      <tr key={u.uid} className="group">
                        <td className="py-4">
                          <div className="flex items-center gap-3">
                            {u.photoURL ? (
                              <img src={u.photoURL} alt="" className="w-8 h-8 rounded-full border border-black/5" referrerPolicy="no-referrer" />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-[#5A5A40]/10 flex items-center justify-center text-[#5A5A40]">
                                <User size={14} />
                              </div>
                            )}
                            <span className="text-sm font-medium">{u.displayName || 'Anonymous'}</span>
                          </div>
                        </td>
                        <td className="py-4 text-sm text-[#1A1A1A]/60">{u.email}</td>
                        <td className="py-4">
                          <select
                            value={u.role}
                            onChange={(e) => handleRoleChange(u.uid, e.target.value as UserRole)}
                            disabled={u.uid === profile.uid}
                            className="bg-white border border-black/5 rounded-xl text-xs px-3 py-1.5 focus:outline-none focus:border-[#5A5A40] disabled:opacity-50"
                          >
                            <option value="viewer">Viewer</option>
                            <option value="manager">Manager</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Non-Admin Message */}
        {profile?.role !== 'admin' && (
          <div className="lg:col-span-2">
            <div className="bg-[#F5F2ED]/50 p-12 rounded-[32px] border border-black/5 border-dashed text-center">
              <Shield size={48} className="mx-auto mb-6 text-[#1A1A1A]/20" />
              <h3 className="text-xl font-serif mb-2">Access Control</h3>
              <p className="text-[#1A1A1A]/60 italic max-w-md mx-auto">
                User management and advanced role assignments are restricted to administrators. 
                Contact your account administrator to request access changes.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
