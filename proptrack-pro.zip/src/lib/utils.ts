import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { Frequency } from '../types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function calculateAnnualizedAmount(amount: number, frequency: Frequency): number {
  switch (frequency) {
    case 'weekly':
      return amount * 52;
    case 'bi-weekly':
      return amount * 26;
    case 'monthly':
      return amount * 12;
    case 'yearly':
      return amount;
    case 'one-time':
    default:
      return amount; // One-time is just the amount for the year it occurred
  }
}

export function calculateMonthlyAmount(amount: number, frequency: Frequency): number {
  switch (frequency) {
    case 'weekly':
      return (amount * 52) / 12;
    case 'bi-weekly':
      return (amount * 26) / 12;
    case 'monthly':
      return amount;
    case 'yearly':
      return amount / 12;
    case 'one-time':
    default:
      return amount / 12; // Spread one-time over the year for monthly view
  }
}

export function calculateMortgagePayment(principal: number, annualInterestRate: number, termYears: number): number {
  if (!principal || !annualInterestRate || !termYears) return 0;
  const monthlyRate = annualInterestRate / 100 / 12;
  const numberOfPayments = termYears * 12;
  if (monthlyRate === 0) return principal / numberOfPayments;
  const payment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
  return payment;
}
