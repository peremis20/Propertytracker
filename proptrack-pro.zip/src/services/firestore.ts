import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  onSnapshot, 
  deleteDoc, 
  addDoc, 
  Timestamp,
  getDocFromServer
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { 
  Property, 
  Expense, 
  Income, 
  Maintenance, 
  Tenant, 
  DocumentMetadata,
  UserProfile,
  UserRole
} from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. The client is offline.");
    }
    // Skip logging for other errors, as this is simply a connection test.
  }
}
testConnection();

// Users
export const getUsers = (callback: (users: UserProfile[]) => void) => {
  if (!auth.currentUser) return () => {};
  const q = collection(db, 'users');
  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map(doc => ({ ...doc.data() } as UserProfile));
    callback(users);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'users'));
};

export const updateUserProfile = async (uid: string, profile: Partial<UserProfile>) => {
  const path = `users/${uid}`;
  try {
    await setDoc(doc(db, 'users', uid), profile, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};
// Properties
export const getProperties = (callback: (properties: Property[]) => void) => {
  if (!auth.currentUser) return () => {};
  const q = query(collection(db, 'properties'), where('ownerId', '==', auth.currentUser.uid));
  return onSnapshot(q, (snapshot) => {
    const properties = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Property));
    callback(properties);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'properties'));
};

export const addProperty = async (property: Omit<Property, 'id' | 'ownerId' | 'createdAt'>) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'properties';
  try {
    const docRef = doc(collection(db, path));
    const id = docRef.id;
    await setDoc(docRef, {
      ...property,
      id,
      ownerId: auth.currentUser.uid,
      createdAt: new Date().toISOString()
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const updateProperty = async (id: string, property: Partial<Property>) => {
  const path = `properties/${id}`;
  try {
    await setDoc(doc(db, 'properties', id), property, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteProperty = async (id: string) => {
  const path = `properties/${id}`;
  try {
    await deleteDoc(doc(db, 'properties', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Expenses
export const getExpenses = (propertyId: string | null, callback: (expenses: Expense[]) => void) => {
  if (!auth.currentUser) return () => {};
  let q = query(collection(db, 'expenses'), where('ownerId', '==', auth.currentUser.uid));
  if (propertyId) {
    q = query(q, where('propertyId', '==', propertyId));
  }
  return onSnapshot(q, (snapshot) => {
    const expenses = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Expense));
    callback(expenses);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'expenses'));
};

export const addExpense = async (expense: Omit<Expense, 'id' | 'ownerId'>) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'expenses';
  try {
    const docRef = doc(collection(db, path));
    const id = docRef.id;
    await setDoc(docRef, {
      ...expense,
      id,
      ownerId: auth.currentUser.uid
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const updateExpense = async (id: string, expense: Partial<Expense>) => {
  const path = `expenses/${id}`;
  try {
    await setDoc(doc(db, 'expenses', id), expense, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteExpense = async (id: string) => {
  const path = `expenses/${id}`;
  try {
    await deleteDoc(doc(db, 'expenses', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Income
export const getIncome = (propertyId: string | null, callback: (income: Income[]) => void) => {
  if (!auth.currentUser) return () => {};
  let q = query(collection(db, 'income'), where('ownerId', '==', auth.currentUser.uid));
  if (propertyId) {
    q = query(q, where('propertyId', '==', propertyId));
  }
  return onSnapshot(q, (snapshot) => {
    const income = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Income));
    callback(income);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'income'));
};

export const addIncome = async (income: Omit<Income, 'id' | 'ownerId'>) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'income';
  try {
    const docRef = doc(collection(db, path));
    const id = docRef.id;
    await setDoc(docRef, {
      ...income,
      id,
      ownerId: auth.currentUser.uid
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const updateIncome = async (id: string, income: Partial<Income>) => {
  const path = `income/${id}`;
  try {
    await setDoc(doc(db, 'income', id), income, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteIncome = async (id: string) => {
  const path = `income/${id}`;
  try {
    await deleteDoc(doc(db, 'income', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Tenants
export const getTenants = (propertyId: string | null, callback: (tenants: Tenant[]) => void) => {
  if (!auth.currentUser) return () => {};
  let q = query(collection(db, 'tenants'), where('ownerId', '==', auth.currentUser.uid));
  if (propertyId) {
    q = query(q, where('propertyId', '==', propertyId));
  }
  return onSnapshot(q, (snapshot) => {
    const tenants = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Tenant));
    callback(tenants);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'tenants'));
};

export const addTenant = async (tenant: Omit<Tenant, 'id' | 'ownerId'>) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'tenants';
  try {
    const docRef = doc(collection(db, path));
    const id = docRef.id;
    await setDoc(docRef, {
      ...tenant,
      id,
      ownerId: auth.currentUser.uid
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const updateTenant = async (id: string, tenant: Partial<Tenant>) => {
  const path = `tenants/${id}`;
  try {
    await setDoc(doc(db, 'tenants', id), tenant, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteTenant = async (id: string) => {
  const path = `tenants/${id}`;
  try {
    await deleteDoc(doc(db, 'tenants', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Maintenance
export const getMaintenance = (propertyId: string | null, callback: (maintenance: Maintenance[]) => void) => {
  if (!auth.currentUser) return () => {};
  let q = query(collection(db, 'maintenance'), where('ownerId', '==', auth.currentUser.uid));
  if (propertyId) {
    q = query(q, where('propertyId', '==', propertyId));
  }
  return onSnapshot(q, (snapshot) => {
    const maintenance = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Maintenance));
    callback(maintenance);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'maintenance'));
};

export const addMaintenance = async (maintenance: Omit<Maintenance, 'id' | 'ownerId'>) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'maintenance';
  try {
    const docRef = doc(collection(db, path));
    const id = docRef.id;
    await setDoc(docRef, {
      ...maintenance,
      id,
      ownerId: auth.currentUser.uid
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const updateMaintenance = async (id: string, maintenance: Partial<Maintenance>) => {
  const path = `maintenance/${id}`;
  try {
    await setDoc(doc(db, 'maintenance', id), maintenance, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteMaintenance = async (id: string) => {
  const path = `maintenance/${id}`;
  try {
    await deleteDoc(doc(db, 'maintenance', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Documents
export const getDocuments = (propertyId: string | null, callback: (documents: DocumentMetadata[]) => void) => {
  if (!auth.currentUser) return () => {};
  let q = query(collection(db, 'documents'), where('ownerId', '==', auth.currentUser.uid));
  if (propertyId) {
    q = query(q, where('propertyId', '==', propertyId));
  }
  return onSnapshot(q, (snapshot) => {
    const documents = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as DocumentMetadata));
    callback(documents);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'documents'));
};

export const addDocument = async (document: Omit<DocumentMetadata, 'id' | 'ownerId' | 'createdAt'>) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'documents';
  try {
    const docRef = doc(collection(db, path));
    const id = docRef.id;
    await setDoc(docRef, {
      ...document,
      id,
      ownerId: auth.currentUser.uid,
      createdAt: new Date().toISOString()
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const deleteDocument = async (id: string) => {
  const path = `documents/${id}`;
  try {
    await deleteDoc(doc(db, 'documents', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Invites
export const getInvites = (callback: (invites: { id: string; email: string; role: UserRole }[]) => void) => {
  if (!auth.currentUser) return () => {};
  const q = collection(db, 'invites');
  return onSnapshot(q, (snapshot) => {
    const invites = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as { id: string; email: string; role: UserRole }));
    callback(invites);
  }, (error) => handleFirestoreError(error, OperationType.LIST, 'invites'));
};

export const addInvite = async (email: string, role: UserRole) => {
  if (!auth.currentUser) throw new Error('User not authenticated');
  const path = 'invites';
  try {
    await setDoc(doc(db, 'invites', email.toLowerCase()), {
      email: email.toLowerCase(),
      role,
      invitedBy: auth.currentUser.uid,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const deleteInvite = async (email: string) => {
  const path = `invites/${email}`;
  try {
    await deleteDoc(doc(db, 'invites', email.toLowerCase()));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};
