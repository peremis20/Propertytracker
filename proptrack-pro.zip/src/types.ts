export type UserRole = 'admin' | 'manager' | 'viewer';

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  role: UserRole;
  createdAt: string;
}

export type PropertyType = 'single' | 'duplex' | 'mobile_home' | 'apartment_complex';
export type PropertyStatus = 'vacant' | 'occupied';

export interface Property {
  id: string;
  ownerId: string;
  name: string;
  address: string;
  type: PropertyType;
  units: number;
  bedrooms: number;
  bathrooms: number;
  sqft: number;
  purchasePrice: number;
  purchaseDate: string;
  monthlyRent: number;
  securityDeposit: number;
  status: PropertyStatus;
  ownerName: string;
  annualTax: number;
  annualInsurance: number;
  // Initial tenant info (optional)
  tenantName?: string;
  tenantEmail?: string;
  tenantPhone?: string;
  leaseStart?: string;
  leaseEnd?: string;
  photos: string[];
  notes: string;
  mortgagePrincipal?: number;
  mortgageInterestRate?: number;
  mortgageTermYears?: number;
  mortgageStartDate?: string;
  createdAt: string;
}

export type Frequency = 'one-time' | 'weekly' | 'bi-weekly' | 'monthly' | 'yearly';

export type ExpenseCategory = 'repairs' | 'utilities' | 'taxes' | 'insurance' | 'management' | 'other';

export interface Expense {
  id: string;
  propertyId: string;
  ownerId: string;
  date: string;
  amount: number;
  category: ExpenseCategory;
  description: string;
  frequency: Frequency;
  receiptUrl?: string;
}

export type IncomeSource = 'rent' | 'parking' | 'laundry' | 'other';
export type IncomeStatus = 'paid' | 'late' | 'missed';

export interface Income {
  id: string;
  propertyId: string;
  ownerId: string;
  date: string;
  amount: number;
  source: IncomeSource;
  status: IncomeStatus;
  frequency: Frequency;
  tenantId?: string;
}

export type MaintenanceCategory = 'repair' | 'improvement' | 'inspection' | 'emergency';
export type MaintenanceStatus = 'pending' | 'in-progress' | 'completed';

export interface Maintenance {
  id: string;
  propertyId: string;
  ownerId: string;
  date: string;
  title: string;
  description: string;
  category: MaintenanceCategory;
  status: MaintenanceStatus;
  cost: number;
  vendor?: string;
  photos: string[];
}

export interface Tenant {
  id: string;
  propertyId: string;
  ownerId: string;
  name: string;
  email?: string;
  phone?: string;
  leaseStart?: string;
  leaseEnd?: string;
  monthlyRent?: number;
  rentDueDate?: number;
}

export type DocumentType = 'tax' | 'insurance' | 'warranty' | 'lease' | 'other';

export interface DocumentMetadata {
  id: string;
  propertyId: string;
  ownerId: string;
  name: string;
  type: DocumentType;
  url: string;
  createdAt: string;
}
